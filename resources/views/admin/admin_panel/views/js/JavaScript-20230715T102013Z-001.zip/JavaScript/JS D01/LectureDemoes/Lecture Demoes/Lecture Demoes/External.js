﻿//alert("welcome from external file ")
//console.log("num ="+num)